<?php
/**
 * jwt.php — tashqi kutubxonasiz, sodda va ishlaydigan JWT (HS256) implementatsiyasi.
 * Production'da firebase/php-jwt kabi tekshirilgan kutubxona ishlatish tavsiya qilinadi,
 * lekin bu versiya qo'shimcha composer/dependency talab qilmasdan ishlaydi.
 */

function base64url_encode(string $data): string
{
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64url_decode(string $data): string
{
    return base64_decode(strtr($data, '-_', '+/'));
}

function jwt_create(array $payload, int $expiresInSeconds = 2592000): string // 30 kun
{
    $header = base64url_encode(json_encode(['alg' => 'HS256', 'typ' => 'JWT']));
    $payload['iat'] = time();
    $payload['exp'] = time() + $expiresInSeconds;
    $payloadEncoded = base64url_encode(json_encode($payload));
    $signature = hash_hmac('sha256', "$header.$payloadEncoded", JWT_SECRET, true);
    $signatureEncoded = base64url_encode($signature);
    return "$header.$payloadEncoded.$signatureEncoded";
}

/** Token to'g'ri bo'lsa payload arrayni, aks holda null qaytaradi */
function jwt_verify(string $token): ?array
{
    $parts = explode('.', $token);
    if (count($parts) !== 3) return null;
    [$header, $payload, $signature] = $parts;

    $expectedSig = base64url_encode(hash_hmac('sha256', "$header.$payload", JWT_SECRET, true));
    if (!hash_equals($expectedSig, $signature)) return null;

    $data = json_decode(base64url_decode($payload), true);
    if (!is_array($data) || !isset($data['exp']) || $data['exp'] < time()) return null;

    return $data;
}

/** Authorization: Bearer <token> headerini o'qib, user_id qaytaradi yoki 401 bilan to'xtaydi */
function require_auth(): int
{
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    if (!preg_match('/Bearer\s+(.+)/i', $authHeader, $m)) {
        json_response(['error' => 'Token topilmadi'], 401);
    }
    $payload = jwt_verify($m[1]);
    if (!$payload || !isset($payload['user_id'])) {
        json_response(['error' => 'Token yaroqsiz yoki muddati o\'tgan'], 401);
    }
    return (int)$payload['user_id'];
}
