<?php
require_once __DIR__ . '/bootstrap.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = trim($_POST['username'] ?? '');
    $p = $_POST['password'] ?? '';
    if (admin_login($pdo, $u, $p)) {
        header('Location: index.php');
        exit;
    }
    $error = 'Login yoki parol noto\'g\'ri';
}
?>
<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>AI Menejer — Admin kirish</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
  body { background: #0f1117; height: 100vh; display:flex; align-items:center; justify-content:center; font-family: 'Segoe UI', sans-serif; }
  .card { background:#181b25; border:1px solid #262a38; border-radius:16px; padding:2rem; width:360px; box-shadow:0 0 40px rgba(0,255,200,.08); }
  .form-control { background:#0f1117; border:1px solid #2a2e3d; color:#fff; }
  .form-control:focus { background:#0f1117; color:#fff; border-color:#00e0c6; box-shadow:0 0 0 .2rem rgba(0,224,198,.2); }
  .btn-neon { background: linear-gradient(90deg,#00e0c6,#5b8cff); border:none; color:#0f1117; font-weight:600; }
</style>
</head>
<body>
<div class="card">
  <h4 class="text-center text-light mb-4">🤖 AI Menejer — Admin</h4>
  <?php if ($error): ?><div class="alert alert-danger py-2"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <form method="post">
    <div class="mb-3">
      <label class="form-label text-light">Login</label>
      <input type="text" name="username" class="form-control" required autofocus>
    </div>
    <div class="mb-3">
      <label class="form-label text-light">Parol</label>
      <input type="password" name="password" class="form-control" required>
    </div>
    <button class="btn btn-neon w-100">Kirish</button>
  </form>
</div>
</body>
</html>
