<?php
require_once __DIR__ . '/bootstrap.php';
admin_require_login();

$settings = $pdo->query('SELECT * FROM settings ORDER BY id DESC LIMIT 1')->fetch() ?: [];

// ---- STATISTIKA ----
$totalUsers = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$totalMessages = (int)$pdo->query('SELECT COUNT(*) FROM conversations')->fetchColumn();
$totalTokens = (int)$pdo->query('SELECT COALESCE(SUM(tokens_used),0) FROM conversations')->fetchColumn();
$todayRequests = (int)$pdo->query('SELECT COUNT(*) FROM api_logs WHERE DATE(created_at) = CURDATE()')->fetchColumn();

// Oxirgi 7 kunlik token sarfi (grafik uchun)
$dailyStats = $pdo->query(
    "SELECT DATE(created_at) d, COALESCE(SUM(tokens_used),0) tokens, COUNT(*) reqs
     FROM api_logs WHERE created_at > (NOW() - INTERVAL 7 DAY)
     GROUP BY DATE(created_at) ORDER BY d"
)->fetchAll();

$recentConversations = $pdo->query(
    "SELECT c.*, u.name, u.device_id FROM conversations c
     JOIN users u ON u.id = c.user_id
     ORDER BY c.id DESC LIMIT 30"
)->fetchAll();

$users = $pdo->query('SELECT * FROM users ORDER BY last_seen DESC LIMIT 50')->fetchAll();
$faqs = $pdo->query('SELECT * FROM faq ORDER BY id DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>AI Menejer — Admin Panel</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<style>
  body { background:#0b0d13; color:#e6e6e6; font-family:'Segoe UI',sans-serif; }
  .navbar { background:#141824; border-bottom:1px solid #232838; }
  .card { background:#141824; border:1px solid #232838; border-radius:14px; }
  .stat-card h2 { color:#00e0c6; font-weight:700; }
  .nav-tabs .nav-link { color:#9aa3b5; border:none; }
  .nav-tabs .nav-link.active { background:transparent; color:#00e0c6; border-bottom:2px solid #00e0c6; }
  textarea, input, select { background:#0b0d13 !important; color:#fff !important; border:1px solid #232838 !important; }
  textarea:focus, input:focus, select:focus { box-shadow:0 0 0 .15rem rgba(0,224,198,.25) !important; border-color:#00e0c6 !important; }
  table { color:#dfe3ec; }
  .badge-user { background:#2a2e3d; }
  .btn-neon { background:linear-gradient(90deg,#00e0c6,#5b8cff); border:none; color:#0b0d13; font-weight:600; }
</style>
</head>
<body>
<nav class="navbar px-4 py-3 mb-4">
  <span class="navbar-brand text-light fw-bold">🤖 AI Menejer — Admin Panel</span>
  <span class="text-secondary ms-auto">
    <?= htmlspecialchars($_SESSION['admin_username']) ?> |
    <a href="logout.php" class="text-danger text-decoration-none">Chiqish</a>
  </span>
</nav>

<div class="container-fluid px-4">

  <?php if (isset($_GET['saved'])): ?>
    <div class="alert alert-success">Sozlamalar saqlandi ✅</div>
  <?php endif; ?>

  <!-- STAT KARTALARI -->
  <div class="row g-3 mb-4">
    <div class="col-md-3"><div class="card p-3 stat-card"><small class="text-secondary">Foydalanuvchilar</small><h2><?= $totalUsers ?></h2></div></div>
    <div class="col-md-3"><div class="card p-3 stat-card"><small class="text-secondary">Jami xabarlar</small><h2><?= $totalMessages ?></h2></div></div>
    <div class="col-md-3"><div class="card p-3 stat-card"><small class="text-secondary">Jami tokenlar</small><h2><?= number_format($totalTokens) ?></h2></div></div>
    <div class="col-md-3"><div class="card p-3 stat-card"><small class="text-secondary">Bugungi so'rovlar</small><h2><?= $todayRequests ?></h2></div></div>
  </div>

  <div class="card p-3 mb-4">
    <canvas id="statsChart" height="80"></canvas>
  </div>

  <ul class="nav nav-tabs mb-3">
    <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab" href="#tab-settings">Sozlamalar</a></li>
    <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tab-conversations">Suhbatlar tarixi</a></li>
    <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tab-users">Foydalanuvchilar</a></li>
    <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#tab-faq">FAQ</a></li>
  </ul>

  <div class="tab-content">
    <!-- SOZLAMALAR -->
    <div class="tab-pane fade show active" id="tab-settings">
      <div class="card p-4">
        <form method="post" action="save_settings.php">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Menejer ismi</label>
              <input type="text" name="manager_name" class="form-control" value="<?= htmlspecialchars($settings['manager_name'] ?? '') ?>" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Wake Word (uyg'otish so'zi)</label>
              <input type="text" name="wake_word" class="form-control" value="<?= htmlspecialchars($settings['wake_word'] ?? '') ?>">
            </div>

            <div class="col-md-6">
              <label class="form-label">Gemini model</label>
              <select name="gemini_model" class="form-select">
                <?php foreach (['gemini-2.0-flash','gemini-2.0-flash-lite','gemini-1.5-pro','gemini-1.5-flash'] as $m): ?>
                  <option value="<?= $m ?>" <?= ($settings['gemini_model'] ?? '') === $m ? 'selected' : '' ?>><?= $m ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Gemini API Key <small class="text-secondary">(faqat o'zgartirmoqchi bo'lsangiz to'ldiring)</small></label>
              <input type="password" name="gemini_api_key" class="form-control" placeholder="••••••••••••">
            </div>

            <div class="col-md-4">
              <label class="form-label">Ovoz</label>
              <select name="voice_gender" class="form-select">
                <option value="female" <?= ($settings['voice_gender'] ?? '') === 'female' ? 'selected' : '' ?>>Ayol</option>
                <option value="male" <?= ($settings['voice_gender'] ?? '') === 'male' ? 'selected' : '' ?>>Erkak</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Gapirish tezligi (0.5 – 2.0)</label>
              <input type="number" step="0.1" min="0.5" max="2.0" name="speech_rate" class="form-control" value="<?= htmlspecialchars($settings['speech_rate'] ?? '1.0') ?>">
            </div>
            <div class="col-md-4">
              <label class="form-label">Til</label>
              <select name="language" class="form-select">
                <option value="uz" <?= ($settings['language'] ?? '') === 'uz' ? 'selected' : '' ?>>O'zbek</option>
                <option value="ru" <?= ($settings['language'] ?? '') === 'ru' ? 'selected' : '' ?>>Rus</option>
                <option value="en" <?= ($settings['language'] ?? '') === 'en' ? 'selected' : '' ?>>Ingliz</option>
              </select>
            </div>

            <div class="col-12">
              <label class="form-label">System Prompt</label>
              <textarea name="system_prompt" rows="6" class="form-control"><?= htmlspecialchars($settings['system_prompt'] ?? '') ?></textarea>
            </div>

            <div class="col-12">
              <label class="form-label">Kompaniya ma'lumotlari</label>
              <textarea name="company_info" rows="4" class="form-control" placeholder="Kompaniya haqida AI bilishi kerak bo'lgan ma'lumotlar..."><?= htmlspecialchars($settings['company_info'] ?? '') ?></textarea>
            </div>
          </div>

          <button class="btn btn-neon mt-4 px-4">Saqlash</button>
        </form>
      </div>
    </div>

    <!-- SUHBATLAR -->
    <div class="tab-pane fade" id="tab-conversations">
      <div class="card p-3">
        <table class="table table-dark table-striped table-sm">
          <thead><tr><th>Foydalanuvchi</th><th>Rol</th><th>Xabar</th><th>Token</th><th>Vaqt</th></tr></thead>
          <tbody>
          <?php foreach ($recentConversations as $c): ?>
            <tr>
              <td><span class="badge badge-user"><?= htmlspecialchars($c['name'] ?: substr($c['device_id'],0,8)) ?></span></td>
              <td><?= $c['role'] === 'assistant' ? '🤖 AI' : '🧑 User' ?></td>
              <td style="max-width:400px"><?= htmlspecialchars(mb_substr($c['message'],0,150)) ?></td>
              <td><?= $c['tokens_used'] ?></td>
              <td><?= $c['created_at'] ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- FOYDALANUVCHILAR -->
    <div class="tab-pane fade" id="tab-users">
      <div class="card p-3">
        <table class="table table-dark table-striped table-sm">
          <thead><tr><th>ID</th><th>Ism</th><th>Device ID</th><th>Oxirgi faollik</th><th>Ro'yxatdan o'tgan</th></tr></thead>
          <tbody>
          <?php foreach ($users as $u): ?>
            <tr>
              <td><?= $u['id'] ?></td>
              <td><?= htmlspecialchars($u['name'] ?: '—') ?></td>
              <td><code><?= htmlspecialchars($u['device_id']) ?></code></td>
              <td><?= $u['last_seen'] ?></td>
              <td><?= $u['created_at'] ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- FAQ -->
    <div class="tab-pane fade" id="tab-faq">
      <div class="card p-3">
        <p class="text-secondary small">FAQ qo'shish uchun to'g'ridan-to'g'ri MySQL <code>faq</code> jadvaliga yozing yoki keyinroq bu yerga forma qo'shiladi.</p>
        <table class="table table-dark table-striped table-sm">
          <thead><tr><th>Savol</th><th>Javob</th></tr></thead>
          <tbody>
          <?php foreach ($faqs as $f): ?>
            <tr><td><?= htmlspecialchars($f['question']) ?></td><td><?= htmlspecialchars($f['answer']) ?></td></tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const ctx = document.getElementById('statsChart');
new Chart(ctx, {
  type: 'line',
  data: {
    labels: <?= json_encode(array_column($dailyStats, 'd')) ?>,
    datasets: [
      { label: 'So\'rovlar', data: <?= json_encode(array_map('intval', array_column($dailyStats,'reqs'))) ?>, borderColor: '#5b8cff', tension:.3 },
      { label: 'Tokenlar', data: <?= json_encode(array_map('intval', array_column($dailyStats,'tokens'))) ?>, borderColor: '#00e0c6', tension:.3 }
    ]
  },
  options: { plugins: { legend: { labels: { color:'#dfe3ec' } } }, scales: { x:{ticks:{color:'#9aa3b5'}}, y:{ticks:{color:'#9aa3b5'}} } }
});
</script>
</body>
</html>
