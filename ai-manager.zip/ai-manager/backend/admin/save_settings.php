<?php
require_once __DIR__ . '/bootstrap.php';
admin_require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare('SELECT id FROM settings ORDER BY id DESC LIMIT 1');
$stmt->execute();
$id = $stmt->fetchColumn();

$fields = [
    'manager_name'   => trim($_POST['manager_name'] ?? 'Aisha'),
    'system_prompt'  => trim($_POST['system_prompt'] ?? ''),
    'gemini_model'   => trim($_POST['gemini_model'] ?? 'gemini-2.0-flash'),
    'voice_gender'   => in_array($_POST['voice_gender'] ?? '', ['male', 'female']) ? $_POST['voice_gender'] : 'female',
    'speech_rate'    => (float)($_POST['speech_rate'] ?? 1.0),
    'language'       => trim($_POST['language'] ?? 'uz'),
    'wake_word'      => trim($_POST['wake_word'] ?? 'Aisha'),
    'company_info'   => trim($_POST['company_info'] ?? ''),
];

// API kalitni faqat bo'sh bo'lmasa yangilaymiz (formani qayta ochganda ko'rsatilmaydi)
$apiKeyProvided = trim($_POST['gemini_api_key'] ?? '');

if ($id) {
    $sql = 'UPDATE settings SET manager_name=?, system_prompt=?, gemini_model=?, voice_gender=?, speech_rate=?, language=?, wake_word=?, company_info=?';
    $params = array_values($fields);
    if ($apiKeyProvided !== '') {
        $sql .= ', gemini_api_key=?';
        $params[] = $apiKeyProvided;
    }
    $sql .= ' WHERE id=?';
    $params[] = $id;
    $pdo->prepare($sql)->execute($params);
} else {
    $fields['gemini_api_key'] = $apiKeyProvided;
    $cols = implode(',', array_keys($fields));
    $placeholders = implode(',', array_fill(0, count($fields), '?'));
    $pdo->prepare("INSERT INTO settings ($cols) VALUES ($placeholders)")->execute(array_values($fields));
}

header('Location: index.php?saved=1');
