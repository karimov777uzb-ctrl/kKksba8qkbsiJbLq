-- ============================================
-- AI MENEJER — MySQL SXEMASI
-- ============================================

CREATE DATABASE IF NOT EXISTS ai_manager CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ai_manager;

-- Admin sozlamalari (bitta qator = joriy konfiguratsiya)
CREATE TABLE IF NOT EXISTS settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    manager_name VARCHAR(100) NOT NULL DEFAULT 'Aisha',
    system_prompt TEXT NOT NULL,
    gemini_api_key VARCHAR(255) NOT NULL DEFAULT '',
    gemini_model VARCHAR(100) NOT NULL DEFAULT 'gemini-2.0-flash',
    voice_gender ENUM('male','female') NOT NULL DEFAULT 'female',
    speech_rate FLOAT NOT NULL DEFAULT 1.0,
    language VARCHAR(10) NOT NULL DEFAULT 'uz',
    wake_word VARCHAR(50) NOT NULL DEFAULT 'Aisha',
    company_info TEXT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO settings (manager_name, system_prompt) VALUES (
  'Aisha',
  'Sen Aisha ismli do\'stona AI menejersan. Foydalanuvchi bilan o\'zbek tilida, qisqa va tabiiy gaplashasan.'
);

-- FAQ
CREATE TABLE IF NOT EXISTS faq (
    id INT PRIMARY KEY AUTO_INCREMENT,
    question VARCHAR(500) NOT NULL,
    answer TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Foydalanuvchilar (mobil ilova qurilmalari)
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    device_id VARCHAR(191) NOT NULL UNIQUE,
    name VARCHAR(100) NULL,
    api_token VARCHAR(255) NOT NULL,
    push_token VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_seen TIMESTAMP NULL
) ENGINE=InnoDB;

-- Suhbatlar tarixi
CREATE TABLE IF NOT EXISTS conversations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    role ENUM('user','assistant') NOT NULL,
    message TEXT NOT NULL,
    tokens_used INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- AI xotirasi (uzoq muddatli, foydalanuvchi bo'yicha kalit-qiymat)
CREATE TABLE IF NOT EXISTS memory (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    fact TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- API so'rovlar logi / rate-limit uchun
CREATE TABLE IF NOT EXISTS api_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NULL,
    endpoint VARCHAR(100) NOT NULL,
    ip_address VARCHAR(64) NOT NULL,
    status_code INT NOT NULL,
    tokens_used INT DEFAULT 0,
    duration_ms INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Admin panel foydalanuvchisi
CREATE TABLE IF NOT EXISTS admins (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

-- DIQQAT: admin qo'shish uchun jadval bo'sh qoldirilgan.
-- db.sql import qilingandan so'ng bir marta backend/seed_admin.php ni brauzerda oching —
-- u login=admin, parol=admin123 bilan xavfsiz (bcrypt) admin yaratadi va o'zini o'chirib tashlaydi.
