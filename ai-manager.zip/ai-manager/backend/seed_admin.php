<?php
/**
 * BIR MARTALIK SKRIPT: dastlabki admin foydalanuvchisini yaratadi.
 * Brauzerda oching (masalan https://sizning-domen.uz/backend/seed_admin.php),
 * ishlatib bo'lgach ushbu faylni serverdan o'chirib tashlang.
 */
require_once __DIR__ . '/config.php';

$username = 'admin';
$password = 'admin123'; // Yaratilgach albatta admin panel ichidan o'zgartiring

$stmt = $pdo->prepare('SELECT COUNT(*) FROM admins');
$stmt->execute();
if ($stmt->fetchColumn() > 0) {
    die('Admin allaqachon mavjud. Xavfsizlik uchun bu faylni o\'chiring.');
}

$hash = password_hash($password, PASSWORD_BCRYPT);
$stmt = $pdo->prepare('INSERT INTO admins (username, password_hash) VALUES (?, ?)');
$stmt->execute([$username, $hash]);

echo "Admin yaratildi. Login: $username / Parol: $password<br>";
echo "<b>ENDI BU FAYLNI SERVERDAN O'CHIRING!</b>";
