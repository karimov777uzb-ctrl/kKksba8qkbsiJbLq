<?php
/**
 * config.php — DB ulanishi va umumiy sozlamalar
 */

// ==== O'ZGARTIRING ====
define('DB_HOST', 'localhost');
define('DB_NAME', 'ai_manager');
define('DB_USER', 'ai_manager_user');
define('DB_PASS', 'CHANGE_ME');

define('JWT_SECRET', 'CHANGE_ME_TO_RANDOM_LONG_STRING'); // openssl rand -hex 32
define('RATE_LIMIT_PER_MIN', 20); // Har bir foydalanuvchi uchun daqiqasiga so'rov limiti
// ========================

date_default_timezone_set('Asia/Tashkent');

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    die(json_encode(['error' => 'DB ulanish xatosi']));
}

/** JSON javob qaytarish va to'xtatish */
function json_response($data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** So'rov tanasini JSON sifatida o'qish */
function json_body(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

/** Xatolarni logga va (agar bor bo'lsa) api_logs jadvaliga yozish */
function log_api(?int $userId, string $endpoint, int $status, int $tokens = 0, int $durationMs = 0): void
{
    global $pdo;
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $stmt = $pdo->prepare(
            'INSERT INTO api_logs (user_id, endpoint, ip_address, status_code, tokens_used, duration_ms) VALUES (?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$userId, $endpoint, $ip, $status, $tokens, $durationMs]);
    } catch (Throwable $e) {
        error_log('log_api xato: ' . $e->getMessage());
    }
}
