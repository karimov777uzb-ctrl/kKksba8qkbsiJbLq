<?php
/**
 * POST /api/chat.php
 * Header: Authorization: Bearer <JWT>
 * Body: { "message": "Foydalanuvchi matni" }
 * Javob: { "reply": "AI javobi", "tokens_used": 123 }
 *
 * Oqim: JWT tekshiruvi -> rate-limit -> settings o'qish -> Gemini API chaqiruvi
 *       -> suhbatni saqlash -> javobni qaytarish
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../jwt.php';

header('Access-Control-Allow-Origin: *');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Faqat POST'], 405);
}

$startTime = microtime(true);
$userId = require_auth();

// ---- RATE LIMIT ----
$stmt = $pdo->prepare(
    'SELECT COUNT(*) FROM api_logs WHERE user_id = ? AND endpoint = "chat" AND created_at > (NOW() - INTERVAL 1 MINUTE)'
);
$stmt->execute([$userId]);
if ((int)$stmt->fetchColumn() >= RATE_LIMIT_PER_MIN) {
    log_api($userId, 'chat', 429);
    json_response(['error' => 'Juda ko\'p so\'rov yubordingiz. Biroz kuting.'], 429);
}

$body = json_body();
$userMessage = trim($body['message'] ?? '');
if ($userMessage === '') {
    json_response(['error' => 'message bo\'sh bo\'lmasligi kerak'], 400);
}

// ---- SOZLAMALARNI O'QISH ----
$settings = $pdo->query('SELECT * FROM settings ORDER BY id DESC LIMIT 1')->fetch();
if (!$settings || empty($settings['gemini_api_key'])) {
    json_response(['error' => 'Gemini API kaliti admin panelda sozlanmagan'], 500);
}

// ---- FOYDALANUVCHI XOTIRASINI QO'SHISH ----
$memStmt = $pdo->prepare('SELECT fact FROM memory WHERE user_id = ? ORDER BY id DESC LIMIT 10');
$memStmt->execute([$userId]);
$facts = array_column($memStmt->fetchAll(), 'fact');
$memoryText = $facts ? ("\n\nFoydalanuvchi haqida ma'lum faktlar:\n- " . implode("\n- ", $facts)) : '';

// ---- OXIRGI SUHBAT TARIXINI OLISH (kontekst uchun, oxirgi 10 ta xabar) ----
$histStmt = $pdo->prepare(
    'SELECT role, message FROM conversations WHERE user_id = ? ORDER BY id DESC LIMIT 10'
);
$histStmt->execute([$userId]);
$history = array_reverse($histStmt->fetchAll());

$contents = [];
foreach ($history as $h) {
    $contents[] = [
        'role' => $h['role'] === 'assistant' ? 'model' : 'user',
        'parts' => [['text' => $h['message']]],
    ];
}
$contents[] = ['role' => 'user', 'parts' => [['text' => $userMessage]]];

$systemPrompt = $settings['system_prompt'] . $memoryText
    . "\n\nHar doim " . ($settings['language'] === 'uz' ? "o'zbek tilida" : $settings['language'])
    . " javob ber. Javoblaring qisqa, tabiiy va suhbat uslubida bo'lsin (ovoz orqali o'qiladi).";

// ---- GEMINI API CHAQIRUVI ----
$model = $settings['gemini_model'] ?: 'gemini-2.0-flash';
$url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . $settings['gemini_api_key'];

$payload = [
    'contents' => $contents,
    'systemInstruction' => ['parts' => [['text' => $systemPrompt]]],
    'generationConfig' => [
        'temperature' => 0.8,
        'maxOutputTokens' => 512,
    ],
];

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
    CURLOPT_TIMEOUT => 30,
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError || $httpCode >= 400) {
    log_api($userId, 'chat', 502, 0, (int)((microtime(true) - $startTime) * 1000));
    json_response(['error' => 'AI xizmatiga ulanishda xato', 'detail' => $curlError ?: $response], 502);
}

$result = json_decode($response, true);
$replyText = $result['candidates'][0]['content']['parts'][0]['text'] ?? null;
$tokensUsed = (int)($result['usageMetadata']['totalTokenCount'] ?? 0);

if (!$replyText) {
    log_api($userId, 'chat', 502, $tokensUsed, (int)((microtime(true) - $startTime) * 1000));
    json_response(['error' => 'AI javob bermadi'], 502);
}

// ---- SUHBATNI SAQLASH ----
$pdo->prepare('INSERT INTO conversations (user_id, role, message, tokens_used) VALUES (?, "user", ?, 0)')
    ->execute([$userId, $userMessage]);
$pdo->prepare('INSERT INTO conversations (user_id, role, message, tokens_used) VALUES (?, "assistant", ?, ?)')
    ->execute([$userId, $replyText, $tokensUsed]);

$durationMs = (int)((microtime(true) - $startTime) * 1000);
log_api($userId, 'chat', 200, $tokensUsed, $durationMs);

json_response([
    'reply' => $replyText,
    'tokens_used' => $tokensUsed,
    'manager_name' => $settings['manager_name'],
    'voice_gender' => $settings['voice_gender'],
    'speech_rate' => (float)$settings['speech_rate'],
    'language' => $settings['language'],
]);
