<?php
/**
 * GET /api/config.php
 * Header: Authorization: Bearer <JWT>
 * Android ilova ishga tushganda AI menejer sozlamalarini (ismi, wake word, ovoz, til)
 * olish uchun chaqiradi. API kalit kabi maxfiy ma'lumotlar qaytarilmaydi.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../jwt.php';

header('Access-Control-Allow-Origin: *');
$userId = require_auth();

$settings = $pdo->query(
    'SELECT manager_name, voice_gender, speech_rate, language, wake_word, company_info FROM settings ORDER BY id DESC LIMIT 1'
)->fetch();

if (!$settings) {
    json_response(['error' => 'Sozlamalar topilmadi'], 404);
}

log_api($userId, 'config', 200);
json_response($settings);
