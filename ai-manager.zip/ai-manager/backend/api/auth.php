<?php
/**
 * POST /api/auth.php
 * Body: { "device_id": "...", "name": "...", "push_token": "..." (ixtiyoriy) }
 * Javob: { "token": "JWT...", "user_id": 5 }
 *
 * Qurilma birinchi marta ulanganda shu endpoint chaqiriladi.
 * device_id — Android'da Settings.Secure.ANDROID_ID orqali olinadi.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../jwt.php';

header('Access-Control-Allow-Origin: *');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Faqat POST'], 405);
}

$body = json_body();
$deviceId = trim($body['device_id'] ?? '');
$name = trim($body['name'] ?? '');
$pushToken = trim($body['push_token'] ?? '');

if ($deviceId === '') {
    json_response(['error' => 'device_id majburiy'], 400);
}

// Mavjud foydalanuvchini topish yoki yangisini yaratish
$stmt = $pdo->prepare('SELECT * FROM users WHERE device_id = ?');
$stmt->execute([$deviceId]);
$user = $stmt->fetch();

if ($user) {
    $stmt = $pdo->prepare('UPDATE users SET last_seen = NOW(), push_token = ? WHERE id = ?');
    $stmt->execute([$pushToken ?: $user['push_token'], $user['id']]);
    $userId = (int)$user['id'];
} else {
    $apiToken = bin2hex(random_bytes(16));
    $stmt = $pdo->prepare(
        'INSERT INTO users (device_id, name, api_token, push_token, last_seen) VALUES (?, ?, ?, ?, NOW())'
    );
    $stmt->execute([$deviceId, $name ?: null, $apiToken, $pushToken ?: null]);
    $userId = (int)$pdo->lastInsertId();
}

$token = jwt_create(['user_id' => $userId]);

log_api($userId, 'auth', 200);
json_response(['token' => $token, 'user_id' => $userId]);
