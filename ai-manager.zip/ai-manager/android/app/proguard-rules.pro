# Hozircha maxsus qoida kerak emas.
# minifyEnabled true qilinsa, Retrofit/Gson model klasslarini saqlab qolish kerak bo'ladi:
# -keep class com.eks.aimanager.data.** { *; }
