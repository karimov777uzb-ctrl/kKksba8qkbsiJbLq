package com.eks.aimanager.viewmodel

/** Ovozli suhbat oynasining joriy holati — avatar animatsiyasi shunga qarab o'zgaradi */
enum class VoiceState {
    IDLE,       // Kutmoqda
    LISTENING,  // Foydalanuvchini tinglayapti
    THINKING,   // Gemini AI dan javob kutmoqda
    SPEAKING    // AI javobini ovoz bilan o'qimoqda
}
