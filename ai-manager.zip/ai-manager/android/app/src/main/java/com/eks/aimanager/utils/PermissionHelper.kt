package com.eks.aimanager.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

object PermissionHelper {

    /** Ovozli suhbat uchun majburiy ruxsat */
    val CORE_PERMISSIONS = arrayOf(Manifest.permission.RECORD_AUDIO)

    /** Telefonni boshqarish funksiyalari uchun qo'shimcha ruxsatlar (ixtiyoriy, kerak bo'lganda so'raladi) */
    val DEVICE_CONTROL_PERMISSIONS = arrayOf(
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS
    )

    fun hasPermission(context: Context, permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    fun hasAllPermissions(context: Context, permissions: Array<String>): Boolean {
        return permissions.all { hasPermission(context, it) }
    }
}
