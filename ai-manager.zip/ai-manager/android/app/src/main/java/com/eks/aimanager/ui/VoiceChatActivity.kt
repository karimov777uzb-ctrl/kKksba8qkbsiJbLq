package com.eks.aimanager.ui

import android.animation.ValueAnimator
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.animation.LinearInterpolator
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.eks.aimanager.data.ChatRepository
import com.eks.aimanager.data.SessionManager
import com.eks.aimanager.databinding.ActivityVoiceChatBinding
import com.eks.aimanager.utils.PhoneActionsHelper
import com.eks.aimanager.utils.VoiceCommandParser
import com.eks.aimanager.viewmodel.ChatViewModel
import com.eks.aimanager.viewmodel.ChatViewModelFactory
import com.eks.aimanager.viewmodel.VoiceState
import java.util.Locale

/**
 * Ovozli suhbat ekrani — ChatGPT Voice uslubida uzluksiz muloqot:
 * Tingla -> Matnga aylantir -> AI ga yubor -> Javobni ovozda o'qi -> Qayta tingla.
 */
class VoiceChatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVoiceChatBinding
    private lateinit var viewModel: ChatViewModel
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private lateinit var phoneActions: PhoneActionsHelper

    private var isContinuousMode = false // Mikrofon bosilganda true bo'ladi, suhbat davom etadi
    private var pulseAnimator: ValueAnimator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVoiceChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val session = SessionManager(this)
        val repository = ChatRepository(session)
        viewModel = ViewModelProvider(this, ChatViewModelFactory(repository))[ChatViewModel::class.java]

        phoneActions = PhoneActionsHelper(this)

        setupTts()
        setupSpeechRecognizer()
        observeViewModel()

        val deviceId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
        viewModel.initSession(deviceId)

        binding.btnMic.setOnClickListener {
            if (isContinuousMode) {
                stopConversation()
            } else {
                startConversation()
            }
        }
    }

    // ---------------------------------------------------------------------
    // TTS (matnni ovozga aylantirish)
    // ---------------------------------------------------------------------
    private fun setupTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val uzbek = Locale("uz", "UZ")
                val result = tts.setLanguage(uzbek)
                // Agar qurilmada o'zbekcha TTS mavjud bo'lmasa, ruscha/inglizchaga tushamiz
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale("ru", "RU"))
                }
            }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                runOnUiThread { viewModel.setState(VoiceState.SPEAKING) }
            }
            override fun onDone(utteranceId: String?) {
                runOnUiThread {
                    viewModel.setState(VoiceState.IDLE)
                    // Suhbat rejimi yoqiq bo'lsa — AI gapirib bo'lgach avtomatik qayta tinglaymiz
                    if (isContinuousMode) startListening()
                }
            }
            override fun onError(utteranceId: String?) {
                runOnUiThread { viewModel.setState(VoiceState.IDLE) }
            }
        })
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ai_reply_${System.currentTimeMillis()}")
    }

    // ---------------------------------------------------------------------
    // STT (nutqni matnga aylantirish)
    // ---------------------------------------------------------------------
    private fun setupSpeechRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                viewModel.setState(VoiceState.LISTENING)
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.trim()
                if (!text.isNullOrEmpty()) {
                    handleUserSpeech(text)
                } else if (isContinuousMode) {
                    startListening() // Hech narsa eshitilmasa — yana tinglashda davom etamiz
                }
            }

            override fun onError(error: Int) {
                // Jimlik yoki vaqtinchalik xato bo'lsa, suhbat rejimida qayta urinamiz
                if (isContinuousMode) {
                    binding.root.postDelayed({ startListening() }, 700)
                } else {
                    viewModel.setState(VoiceState.IDLE)
                }
            }

            override fun onRmsChanged(rmsdB: Float) {
                // Ovoz balandligiga qarab avatar animatsiyasini biroz kattalashtirish mumkin
            }

            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { viewModel.setState(VoiceState.THINKING) }
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
        })
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200)
        }
        speechRecognizer.startListening(intent)
    }

    private fun handleUserSpeech(text: String) {
        binding.tvTranscript.text = "🧑 $text"

        // Avval mahalliy buyruq bo'lsa (xarita, wifi, kamera va h.k.) — API chaqirmasdan bajaramiz
        when (val command = VoiceCommandParser.parse(text)) {
            is VoiceCommandParser.Command.OpenMap -> {
                phoneActions.openMap(command.query)
                speak("Xaritani ochyapman")
                return
            }
            VoiceCommandParser.Command.OpenWifi -> { phoneActions.openWifiSettings(); speak("Wi-Fi sozlamalari ochildi"); return }
            VoiceCommandParser.Command.OpenBluetooth -> { phoneActions.openBluetoothSettings(); speak("Bluetooth sozlamalari ochildi"); return }
            VoiceCommandParser.Command.OpenCamera -> { phoneActions.openCamera(); speak("Kamera ochilmoqda"); return }
            VoiceCommandParser.Command.OpenGallery -> { phoneActions.openGallery(); speak("Galereya ochilmoqda"); return }
            VoiceCommandParser.Command.None -> { /* AI ga yuboramiz */ }
        }

        viewModel.sendToAi(text)
    }

    private fun startConversation() {
        isContinuousMode = true
        binding.tvStatus.text = "Tinglayapman..."
        startListening()
    }

    private fun stopConversation() {
        isContinuousMode = false
        speechRecognizer.stopListening()
        tts.stop()
        viewModel.setState(VoiceState.IDLE)
        binding.tvStatus.text = "To'xtatildi"
    }

    // ---------------------------------------------------------------------
    // ViewModel kuzatuvi -> UI va avatar animatsiyasini yangilash
    // ---------------------------------------------------------------------
    private fun observeViewModel() {
        viewModel.state.observe(this) { state ->
            when (state) {
                VoiceState.IDLE -> { binding.tvStatus.text = "Tinglashga tayyor..."; stopPulse() }
                VoiceState.LISTENING -> { binding.tvStatus.text = "Tinglayapman..."; startPulse(900) }
                VoiceState.THINKING -> { binding.tvStatus.text = "O'ylayapman..."; startPulse(500) }
                VoiceState.SPEAKING -> { binding.tvStatus.text = "Gapiryapman..."; startPulse(650) }
                else -> {}
            }
        }

        viewModel.aiReply.observe(this) { reply ->
            binding.tvTranscript.text = "🤖 $reply"
            speak(reply)
        }

        viewModel.managerConfig.observe(this) { config ->
            binding.tvManagerName.text = config.manager_name
        }

        viewModel.errorMessage.observe(this) { msg ->
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Avatar halqasining oddiy "pulslash" animatsiyasi (scale 1.0 -> 1.08 -> 1.0).
     * To'liq lab-sync/ko'z-pirpirash animatsiyasi o'rniga soddalashtirilgan,
     * lekin barcha holatlarda (tinglash/o'ylash/gapirish) vizual fikr-mulohaza beradi.
     * Kengaytirish uchun: Lottie fayl qo'shib LottieAnimationView bilan almashtiring.
     */
    private fun startPulse(durationMs: Long) {
        stopPulse()
        pulseAnimator = ValueAnimator.ofFloat(1.0f, 1.08f).apply {
            duration = durationMs
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                val scale = it.animatedValue as Float
                binding.avatarRing.scaleX = scale
                binding.avatarRing.scaleY = scale
            }
            start()
        }
    }

    private fun stopPulse() {
        pulseAnimator?.cancel()
        binding.avatarRing.scaleX = 1.0f
        binding.avatarRing.scaleY = 1.0f
    }

    override fun onDestroy() {
        speechRecognizer.destroy()
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
