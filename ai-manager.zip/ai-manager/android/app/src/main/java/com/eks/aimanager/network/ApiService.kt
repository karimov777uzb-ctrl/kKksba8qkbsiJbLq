package com.eks.aimanager.network

import com.eks.aimanager.data.AuthRequest
import com.eks.aimanager.data.AuthResponse
import com.eks.aimanager.data.ChatRequest
import com.eks.aimanager.data.ChatResponse
import com.eks.aimanager.data.ManagerConfig
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

interface ApiService {

    @POST("api/auth.php")
    suspend fun authenticate(@Body request: AuthRequest): Response<AuthResponse>

    @POST("api/chat.php")
    suspend fun sendMessage(
        @Header("Authorization") bearerToken: String,
        @Body request: ChatRequest
    ): Response<ChatResponse>

    @GET("api/config.php")
    suspend fun getConfig(@Header("Authorization") bearerToken: String): Response<ManagerConfig>
}
