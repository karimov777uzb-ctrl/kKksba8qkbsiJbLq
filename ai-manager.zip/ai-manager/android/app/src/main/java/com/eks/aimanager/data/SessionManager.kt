package com.eks.aimanager.data

import android.content.Context
import android.content.SharedPreferences

/**
 * Token va foydalanuvchi ma'lumotlarini qurilmada saqlaydi.
 * Production'da EncryptedSharedPreferences ishlatish tavsiya etiladi.
 */
class SessionManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("ai_manager_session", Context.MODE_PRIVATE)

    var token: String?
        get() = prefs.getString("jwt_token", null)
        set(value) = prefs.edit().putString("jwt_token", value).apply()

    var userId: Int
        get() = prefs.getInt("user_id", -1)
        set(value) = prefs.edit().putInt("user_id", value).apply()

    fun bearerToken(): String = "Bearer ${token ?: ""}"

    fun isLoggedIn(): Boolean = !token.isNullOrEmpty()

    fun clear() = prefs.edit().clear().apply()
}
