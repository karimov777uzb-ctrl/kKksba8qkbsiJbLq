package com.eks.aimanager

import android.app.Application

class AiManagerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Bu yerda global initsializatsiya (masalan, crash-reporting) qo'shilishi mumkin
    }
}
