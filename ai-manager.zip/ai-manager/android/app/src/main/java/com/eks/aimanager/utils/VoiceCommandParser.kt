package com.eks.aimanager.utils

/**
 * Foydalanuvchi gapirgan matnda oddiy kalit so'zlarni qidiradi va agar telefon
 * amali bo'lsa, uni to'g'ridan-to'g'ri bajaradi (Gemini API ga yubormasdan —
 * bu ham tezroq ishlaydi, ham token sarfini kamaytiradi).
 *
 * Bu — soddalashtirilgan qoida-asosli parser. Kelajakda buni Gemini'ning
 * "function calling" imkoniyati bilan almashtirish mumkin.
 */
object VoiceCommandParser {

    sealed class Command {
        data class OpenMap(val query: String) : Command()
        object OpenWifi : Command()
        object OpenBluetooth : Command()
        object OpenCamera : Command()
        object OpenGallery : Command()
        object None : Command() // Buyruq topilmadi — matn AI ga yuboriladi
    }

    fun parse(text: String): Command {
        val t = text.lowercase().trim()

        return when {
            t.contains("xarita") || t.contains("qanday borish") -> {
                val query = t.replace("xaritada", "").replace("xarita", "").trim()
                Command.OpenMap(query.ifBlank { "restoran" })
            }
            t.contains("wifi") || t.contains("wi-fi") || t.contains("vay fay") ->
                Command.OpenWifi

            t.contains("bluetooth") || t.contains("blyutuz") ->
                Command.OpenBluetooth

            t.contains("kamera") && (t.contains("och") || t.contains("yoq")) ->
                Command.OpenCamera

            t.contains("galere") && (t.contains("och") || t.contains("ko'rsat")) ->
                Command.OpenGallery

            else -> Command.None
        }
    }
}
