package com.eks.aimanager.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.eks.aimanager.data.ApiResult
import com.eks.aimanager.data.ChatRepository
import com.eks.aimanager.data.ManagerConfig
import kotlinx.coroutines.launch

/**
 * VoiceChatActivity uchun ViewModel.
 * Barcha biznes-mantiq (tarmoq chaqiruvlari, holatlarni boshqarish) shu yerda,
 * Activity faqat UI va Android STT/TTS bilan ishlaydi (Repository Pattern + MVVM).
 */
class ChatViewModel(private val repository: ChatRepository) : ViewModel() {

    private val _state = MutableLiveData(VoiceState.IDLE)
    val state: LiveData<VoiceState> = _state

    private val _aiReply = MutableLiveData<String>()
    val aiReply: LiveData<String> = _aiReply

    private val _errorMessage = MutableLiveData<String>()
    val errorMessage: LiveData<String> = _errorMessage

    private val _managerConfig = MutableLiveData<ManagerConfig>()
    val managerConfig: LiveData<ManagerConfig> = _managerConfig

    fun setState(newState: VoiceState) {
        _state.value = newState
    }

    /** Ilova ishga tushganda: avval device auth, keyin AI sozlamalarini yuklash */
    fun initSession(deviceId: String) {
        viewModelScope.launch {
            when (val authResult = repository.authenticate(deviceId, null)) {
                is ApiResult.Success -> loadConfig()
                is ApiResult.Error -> _errorMessage.value = authResult.message
            }
        }
    }

    private fun loadConfig() {
        viewModelScope.launch {
            when (val result = repository.getConfig()) {
                is ApiResult.Success -> _managerConfig.value = result.data
                is ApiResult.Error -> _errorMessage.value = result.message
            }
        }
    }

    /** Foydalanuvchi gapirgan matnni AI ga yuborish */
    fun sendToAi(userText: String) {
        _state.value = VoiceState.THINKING
        viewModelScope.launch {
            when (val result = repository.sendMessage(userText)) {
                is ApiResult.Success -> {
                    _aiReply.value = result.data.reply
                    _state.value = VoiceState.SPEAKING
                }
                is ApiResult.Error -> {
                    _errorMessage.value = result.message
                    _state.value = VoiceState.IDLE
                }
            }
        }
    }
}

/** ViewModel'ni Repository bilan yaratish uchun sodda factory (Hilt/Koin ishlatilmasa ham ishlaydi) */
class ChatViewModelFactory(private val repository: ChatRepository) :
    androidx.lifecycle.ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return ChatViewModel(repository) as T
    }
}
