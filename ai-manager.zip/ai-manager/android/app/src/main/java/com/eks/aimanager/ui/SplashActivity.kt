package com.eks.aimanager.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.eks.aimanager.utils.PermissionHelper

class SplashActivity : AppCompatActivity() {

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        // Foydalanuvchi rad etsa ham davom etamiz — VoiceChatActivity ichida
        // funksiyalar kerak bo'lganda ruxsatni qayta so'raydi.
        goToVoiceChat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (PermissionHelper.hasAllPermissions(this, PermissionHelper.CORE_PERMISSIONS)) {
            goToVoiceChat()
        } else {
            permissionLauncher.launch(PermissionHelper.CORE_PERMISSIONS)
        }
    }

    private fun goToVoiceChat() {
        startActivity(Intent(this, VoiceChatActivity::class.java))
        finish()
    }
}
