package com.eks.aimanager.data

// ---- So'rovlar ----
data class AuthRequest(
    val device_id: String,
    val name: String? = null,
    val push_token: String? = null
)

data class ChatRequest(val message: String)

// ---- Javoblar ----
data class AuthResponse(
    val token: String,
    val user_id: Int
)

data class ChatResponse(
    val reply: String,
    val tokens_used: Int,
    val manager_name: String?,
    val voice_gender: String?,
    val speech_rate: Float?,
    val language: String?
)

data class ManagerConfig(
    val manager_name: String,
    val voice_gender: String,
    val speech_rate: Float,
    val language: String,
    val wake_word: String,
    val company_info: String?
)

data class ApiError(val error: String)
