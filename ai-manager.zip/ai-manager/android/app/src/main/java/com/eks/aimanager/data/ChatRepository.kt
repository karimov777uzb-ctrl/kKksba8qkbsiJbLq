package com.eks.aimanager.data

import com.eks.aimanager.network.RetrofitClient

/** Natijani xato/holat bilan birga qaytaruvchi sodda wrapper */
sealed class ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>()
    data class Error(val message: String) : ApiResult<Nothing>()
}

class ChatRepository(private val session: SessionManager) {

    /** Qurilmani ro'yxatdan o'tkazish / token olish */
    suspend fun authenticate(deviceId: String, name: String?): ApiResult<AuthResponse> {
        return try {
            val response = RetrofitClient.api.authenticate(AuthRequest(deviceId, name))
            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                session.token = body.token
                session.userId = body.user_id
                ApiResult.Success(body)
            } else {
                ApiResult.Error("Ro'yxatdan o'tishda xato: ${response.code()}")
            }
        } catch (e: Exception) {
            ApiResult.Error("Tarmoq xatosi: ${e.localizedMessage}")
        }
    }

    /** AI menejer sozlamalarini olish (ism, wake word, ovoz turi) */
    suspend fun getConfig(): ApiResult<ManagerConfig> {
        return try {
            val response = RetrofitClient.api.getConfig(session.bearerToken())
            if (response.isSuccessful && response.body() != null) {
                ApiResult.Success(response.body()!!)
            } else {
                ApiResult.Error("Sozlamalarni olishda xato: ${response.code()}")
            }
        } catch (e: Exception) {
            ApiResult.Error("Tarmoq xatosi: ${e.localizedMessage}")
        }
    }

    /** Foydalanuvchi xabarini Gemini AI ga yuborish */
    suspend fun sendMessage(message: String): ApiResult<ChatResponse> {
        return try {
            val response = RetrofitClient.api.sendMessage(session.bearerToken(), ChatRequest(message))
            if (response.isSuccessful && response.body() != null) {
                ApiResult.Success(response.body()!!)
            } else {
                ApiResult.Error("AI javob bermadi: ${response.code()}")
            }
        } catch (e: Exception) {
            ApiResult.Error("Tarmoq xatosi: ${e.localizedMessage}")
        }
    }
}
