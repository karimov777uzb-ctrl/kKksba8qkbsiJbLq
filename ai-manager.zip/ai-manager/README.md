# AI Menejer — Android + PHP/MySQL (soddalashtirilgan, ishlaydigan versiya)

Bu — to'liq texnik topshiriqning **ishga tushiriladigan yadrosi**. Murakkab qismlar
(to'liq anime lip-sync 60FPS, 15+ Android ruxsatining barchasi, push-xabar tizimi)
soddalashtirilgan, lekin arxitektura shunday qurilganki, ularni keyin osongina qo'shish mumkin.

## Tuzilma

```
ai-manager/
  backend/          -> PHP 8 + MySQL REST API + Admin panel
    db.sql              -> MySQL sxema
    config.php          -> DB va umumiy sozlamalar (BU YERNI TO'LDIRING)
    jwt.php              -> Sodda JWT (tashqi kutubxonasiz)
    seed_admin.php       -> Birinchi admin foydalanuvchini yaratadi (bir martalik)
    api/
      auth.php            -> Qurilmani ro'yxatdan o'tkazish -> JWT token
      chat.php             -> Gemini API proxy (asosiy ovozli suhbat logikasi)
      config.php           -> Menejer sozlamalarini ilovaga yuborish
    admin/
      login.php, index.php, save_settings.php, logout.php

  android/          -> Kotlin, MVVM + Repository Pattern
    app/src/main/java/com/eks/aimanager/
      data/        -> Model, Repository, SessionManager (JWT saqlash)
      network/     -> Retrofit ApiService + Client
      viewmodel/   -> ChatViewModel (STT/TTS'dan mustaqil biznes-mantiq)
      ui/          -> SplashActivity, VoiceChatActivity (STT+TTS+avatar animatsiyasi)
      utils/       -> PermissionHelper, PhoneActionsHelper, VoiceCommandParser
```

## O'rnatish — Backend

1. `backend/db.sql` faylini MySQL'ga import qiling.
2. `backend/config.php` ichida `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS` va
   `JWT_SECRET` (masalan `openssl rand -hex 32` bilan) ni to'ldiring.
3. `backend/` papkasini serveringizga (Apache/Nginx + PHP 8.2+) joylashtiring.
4. Brauzerda `https://domen.uz/backend/seed_admin.php` ni bir marta oching —
   `admin` / `admin123` bilan admin yaratiladi. **Shundan so'ng faylni o'chiring.**
5. `https://domen.uz/backend/admin/login.php` orqali kiring va:
   - Gemini API Key kiriting (https://aistudio.google.com/apikey)
   - Menejer ismi, system prompt, ovoz, tilni sozlang.

## O'rnatish — Android

1. Android Studio'da `android/` papkasini oching.
2. `network/RetrofitClient.kt` ichida `BASE_URL` ni backend manzilingizga
   o'zgartiring (masalan `https://domen.uz/backend/`).
3. Ilovani qurib, qurilma/emulyatorda ishga tushiring — birinchi ochilishda
   mikrofon ruxsati so'raladi, keyin ovozli suhbat oynasi ochiladi.

## Ishlash printsipi (oqim)

```
[Mikrofon tugmasi] -> SpeechRecognizer (STT, uz-UZ)
     -> matn mahalliy VoiceCommandParser'dan o'tadi
        (xarita/wifi/bluetooth/kamera kabi so'zlar bo'lsa — API'siz bajariladi)
     -> aks holda ChatRepository.sendMessage() -> backend/api/chat.php
     -> chat.php Gemini API'ga so'rov yuboradi (suhbat tarixi + xotira bilan)
     -> javob qaytadi -> TextToSpeech orqali o'qiladi
     -> gapirib bo'lgach avtomatik qayta tinglash boshlanadi (uzluksiz suhbat)
```

## Nima soddalashtirilgan (keyingi bosqichda kengaytiriladi)

- **Avatar**: to'liq anime 2D lip-sync/ko'z-pirpirash o'rniga — holatga qarab
  (tinglash/o'ylash/gapirish) pulslaydigan neon halqa animatsiyasi. Buni
  Lottie fayl (`LottieAnimationView`) yoki sprite-sheet bilan almashtirish
  arxitekturani o'zgartirmasdan mumkin — faqat `VoiceChatActivity`dagi
  `startPulse()`ni almashtirasiz.
- **Telefonni boshqarish**: eng ko'p ishlatiladigan amallar (qo'ng'iroq, SMS,
  kamera, galereya, xarita, budilnik, taqvim, Wi-Fi/Bluetooth) `PhoneActionsHelper`
  orqali tayyor. Ularni AI javobiga ulash uchun Gemini'ning **function calling**
  (tool use) imkoniyatini `chat.php`ga qo'shish tavsiya etiladi.
- **Push xabarlar**: `users.push_token` ustuni tayyor — Firebase Cloud Messaging
  ulanishi kerak (backend yoki alohida cron orqali).
- **Wake Word ("Aisha, eshit")**: hozircha mikrofon tugmasi orqali boshlanadi.
  Doimiy wake-word tinglash uchun Porcupine (Picovoice) kabi on-device kutubxona
  qo'shish tavsiya etiladi (battery/permission talablari yuqori bo'lgani uchun
  bu versiyada kiritilmadi).

## APK faylni telefondan olish (Android Studio kerak emas!)

Bu loyihada `.github/workflows/build-apk.yml` bor — GitHub'ning bepul serverlarida
avtomatik APK yig'ib beradi. Faqat telefon brauzeri yoki GitHub ilovasi kifoya:

1. **GitHub'da repository yarating**: github.com'ga kiring (yo'q bo'lsa ro'yxatdan o'ting) →
   "New repository" → nom bering (masalan `ai-manager`) → Create.
2. **Kodni yuklang**: repository sahifasida "Add file" → "Upload files" → ushbu
   zip'dan chiqargan `ai-manager` papkasidagi barcha fayl/papkalarni tashlang → Commit.
   (Agar zip'ni to'g'ridan-to'g'ri yuklab bo'lmasa, kompyuteringiz yo'q bo'lsa ham
   GitHub mobil ilovasi orqali papka-papka yuklash mumkin, yoki do'stingizdan
   bir martalik yordam so'rab `git push` qildirish eng tez yo'l.)
3. Yuklangach, repository'dagi **"Actions"** bo'limiga o'ting — "Build APK" ishi
   avtomatik boshlanadi (2-4 daqiqa davom etadi).
4. Ish tugagach, o'sha sahifada pastda **"Artifacts"** ostida
   `ai-manager-debug-apk` degan faylni ko'rasiz — shu yerdan yuklab oling
   (zip ichida `app-debug.apk` bo'ladi).
5. Telefoningizga APK'ni ko'chiring, "Noma'lum manbalardan o'rnatish"ga ruxsat
   berib o'rnating.

**Eslatma:** bu — *debug* APK (rivojlantirish uchun, imzosiz). Play Store'ga
chiqarish yoki do'stlaringizga tarqatish uchun keyinroq "release" build va
imzo (signing key) kerak bo'ladi — xohlasangiz shuni ham sozlab beraman.



- `seed_admin.php`ni ishlatgach albatta serverdan o'chiring.
- `JWT_SECRET` va DB parolini production'da kuchli qiymatlarga almashtiring.
- Gemini API kaliti faqat backend'da saqlanadi, Android ilovaga umuman
  yuborilmaydi — bu xavfsizlik uchun muhim.
